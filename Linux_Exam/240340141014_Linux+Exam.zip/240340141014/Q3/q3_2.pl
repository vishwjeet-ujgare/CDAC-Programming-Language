#ask the usr to enter the arrray of numbers for example 1,2,3,4,5,6,7,8 and print the second largest and second smallest number
#sample input : 1,2,3,4,5,6,7,8,
#sample output
	#second larget numbver 20
	#second smallest numbver 16


#i have did this programing using functions

#!/usr/bin/perl

use strict;
use warnings;

#function for taking array from usr separated buy spaces only
sub read_array_of_numbers {
    print "Enter a array of numbers separated by spaces: ";
    

    my @nums = split(' ', <STDIN>);
    return @nums;
}

sub find_second_smallest {
    my @nums = @_;
    my @sorted = sort { $a <=> $b } @nums;
    return $sorted[1];
}

sub find_second_largest {
    my @nums = @_;
    my @sorted = sort { $b <=> $a } @nums;
    return $sorted[1];
}


#starting point of programe
my @numbers = read_array_of_numbers();
my $second_smallest = find_second_smallest(@numbers);
my $second_largest = find_second_largest(@numbers);

print "The second smallest number is: $second_smallest\n";
print "The second largest number is: $second_largest\n";

