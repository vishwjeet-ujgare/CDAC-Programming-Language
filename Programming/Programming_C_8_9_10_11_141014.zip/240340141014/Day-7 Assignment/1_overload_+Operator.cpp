#include <iostream>
using namespace std;

class Box
{

public:
    int length;
    int breadth;
    void operator++()
    {
        length++;
        breadth++;
    }
};

int main()
{

    Box b;
    int length;
    int breadth;

    cout << "Enter the length." << endl;
    cin >> b.length;

    cout << "Enter the breadth" << endl;
    cin >> b.breadth;
    ++b;

    cout << "NL" <<b.length<<endl;
    cout << "NB" << b.breadth<<endl;
    return 0;
}
