#include <iostream>

using namespace std;

class Shape {
public:
    virtual double perimeter() const = 0; 
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}

    double perimeter() const override {
        return 2 * 3.14159 * radius;
    }
};

class Rectangle : public Shape {
private:
    double length, width;
public:
    Rectangle(double l, double w) : length(l), width(w) {}

    double perimeter() const override {
        return 2 * (length + width);
    }
};

int main() {
    
    Circle circle(5);
    cout << "Perimeter of Circle: " << circle.perimeter() << endl;

    
    Rectangle rectangle(4, 6);
    cout << "Perimeter of Rectangle: " << rectangle.perimeter() << endl;

    return 0;
}