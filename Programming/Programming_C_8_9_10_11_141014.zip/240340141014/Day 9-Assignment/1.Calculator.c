#include <stdio.h>
float add(float num1, float num2);
float sub(float num1, float num2);
float mul(float num1, float num2);
float div(float num1, float num2);

int main()
{

    float num1, num2;
    char op;
    printf("Enter first number:\n");
    scanf("%f", &num1);

    printf("Enter he second number:\n");
    scanf("%f", &num2);
    printf("Enter operator (+,-,*,/):\n");
    scanf("%c", &op);

    switch (op)
    {
    case '+':
        printf("%.2f+%.2f=%.2f\n", num1, num2, add(num1, num2));
        break;

    case '-':
        printf("%.2f+%.2f=%.2f\n", num1, num2, sub(num1, num2));
        break;

    case '*':
        printf("%.2f+%.2f=%.2f\n", num1, num2, mul(num1, num2));
        break;

    case '/':
        if (num2 == 0)
        {
            printf("Error!Divison by zero.\n");
        }
        else
        {

            printf("%.2f+%.2f=%.2f\n", num1, num2, div(num1, num2));
        }

        break;

    default:
        printf("Invalid Operatin\n");
    }
    return 0;
}

float add(float num1, float num2)
{

    return num1 + num2;
}

float sub(float num1, float num2)
{

    return num1 - num2;
}

float mul(float num1, float num2)
{

    return num1 * num2;
}

float div(float num1, float num2)
{

    return num1 / num2;
}