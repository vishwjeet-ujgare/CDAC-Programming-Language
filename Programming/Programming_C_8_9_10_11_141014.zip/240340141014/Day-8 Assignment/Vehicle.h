#include <iostream>
#include <string>
using namespace std;

class Vehicle
{
public:
    string name;
    string color;
    int speed;

public:
    void print()
    {
        cout << "Name=" << name << endl;
        cout << "Color=" << color << endl;
        cout << "Speed=" << speed << endl;
    }

    void start()
    {

        cout << "Vehicle is starting." << endl;
    }
};