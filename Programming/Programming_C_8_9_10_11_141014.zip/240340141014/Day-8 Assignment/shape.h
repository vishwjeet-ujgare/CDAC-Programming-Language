#include<iostream>
#pragma once
using namespace std;
 class  Shape{

    public:

    float areaOfRect;
    float areaOfsquare;
    float circlearea;

public:
    void print()
    {
        cout<<"============================\n";
        cout<<"Area of rectangle:"<<areaOfRect<<endl;
        cout<<"Area of Square:"<<areaOfsquare<<endl;
        cout << "Area of circle"<<circlearea << endl;


    }

    void area()
    {
        cout << "Every shape have area." << endl;
    }

};