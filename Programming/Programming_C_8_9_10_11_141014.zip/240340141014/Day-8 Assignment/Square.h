#include<iostream>
#include"Rectaangle.h"
using namespace std;

class Square : public  Rectangle{


public:
float side;
    void area(){
    
    float areaOfsquare=side*side;
    cout<<"Area of square:"<<areaOfsquare<<endl;


    }
};