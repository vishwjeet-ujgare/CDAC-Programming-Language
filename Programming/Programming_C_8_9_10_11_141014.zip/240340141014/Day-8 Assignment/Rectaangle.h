#include<iostream>
#pragma once
#include"shape.h"
using namespace std;
class Rectangle : public Shape {
    public:
    float length;
    float breadth;

void area(){
    
    float areaOfRect=length*breadth;
    cout<<"Area of rectangle:"<<areaOfRect<<endl;

}

};
