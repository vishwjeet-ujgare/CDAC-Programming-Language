#include<iostream>
#include"shape.h"
using namespace std;

class Circle :public Shape{

public:
float radius;
    void area()
    {
        
        float circlearea=3.14* radius *radius;

        cout << "Area of circle"<<circlearea << endl;
    }


};