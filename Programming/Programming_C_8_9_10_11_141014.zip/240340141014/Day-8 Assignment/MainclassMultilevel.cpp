#include <iostream>
#include "Circle.h"
#include "Square.h"
#include "Rectaangle.h"
#include "shape.h"

using namespace std;

class Mainclass
{
};

int main()
{

  Rectangle r1;
  Square s1;
  Circle c1;
  Shape s2;

  cout << "Enter radius,side, length and breadth" << endl;
  cin >> r1.length;
  cin >> r1.breadth;
  cin >> s1.side;
  cin >> c1.radius;

  r1.area();
  s1.area();
  c1.area();

  return 0;
}