#include <iostream>
#include <string>
#include "Vehicle.h"
using namespace std;

class Car : public Vehicle
{

public:
    string transmission;

    void print()
    {

        Vehicle::print();

        cout << "Transmission=" << transmission << endl;
    }

    void start()
    {

        cout << "The car engin start in diffrent way than other vehicles." << endl;
    }
};