#include <iostream>
#include <string>
using namespace std;

class Student
{

public:
    int id;
    string name;
    int marks;

    Student()
    {
        id = 0;
        name = "abc";
        marks = 20;
    }

    Student(int id, string name, int marks)
    {

        this->id = id;
        this->name = name;
        this->marks = marks;
    }

    Student(Student &s)
    {

        id = s.id;
        name = s.name;
        marks = s.marks;
    }

    ~Student()
    {
        cout << "Kiling Object." << endl;
    }
    
    void print()
    {
        cout << "Id=" << id << endl;
        cout << "Name=" << name << endl;
        cout << "Marks=" << marks << endl;
    }
};

int main()
{

    Student s;
    s.id = 10;
    s.name = "abc";
    s.marks = 20;
    s.print();
    return 0;
}
