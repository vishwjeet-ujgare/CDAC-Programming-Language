#include <iostream>
using namespace std;

class AreaFinder
{
public:
    float area;

    void calArea(float radius)
    {

        area = 3.14 * radius * radius;
        cout << "Area of circle=" << area << "\n";
    }

    void calArea(int side)
    {
        area = side * side;
        cout << "Area of squre =" << area << "\n";
    }

    void calArea(int length, int breadth)
    {

        area = length * breadth;
        cout << "Area of rectangle=" << area << "\n";
    }
};

int main()
{

    AreaFinder a;
    float area ;
    int side ;
    int length ;
    int breadth ;

    cout << "Enter radius." << endl;
    cin >> area;

    cout << "Enter the side of squre." << endl;
    cin >> side;

    cout << "Enter length and breadth." << endl;
    cin >> length;
    cin>>breadth;

    a.calArea(area);
    a.calArea(side);
    a.calArea(length, breadth);

    return 0;
}