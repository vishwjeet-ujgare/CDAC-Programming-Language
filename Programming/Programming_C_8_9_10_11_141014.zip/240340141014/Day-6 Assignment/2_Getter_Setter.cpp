#include <iostream>
#include <string>
using namespace std;

class Student
{

private:
    int id;
    string name;
    int marks;

public:
    Student()
    {
        id = 0;
        name = "abc";
        marks = 20;
    }

    Student(int id, string name, int marks)
    {

        this->id = id;
        this->name = name;
        this->marks = marks;
    }

    Student(Student &s){

        id=s.id;
        name=s.name;
        marks=s.marks;
    }

     ~ Student()
    {
        cout << "Kiling Object." << endl;
    }

int getId(){
    return id;
}

string getName(){
    return name;
}

int getMarks(){
    return marks;
}

void setId(int id){
    this->id=id;
}

void setName(string name){
    this->name=name;
}

void setMarks(int marks){
    this->marks=marks;
}
    void print()
    {
        cout << "Id=" << id << endl;
        cout << "Name=" << name << endl;
        cout << "Marks=" << marks << endl;
    }
};

int main(){

Student s1;
s1.setId(1);
s1.setName("xyz");
s1.setMarks(50);

cout<<"Printing all the details"<<endl;
s1.print();

cout<<"Printing id:"<<s1.getId()<<endl;

    return 0;
}