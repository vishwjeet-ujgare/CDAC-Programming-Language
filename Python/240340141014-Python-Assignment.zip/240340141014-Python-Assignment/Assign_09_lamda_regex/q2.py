import re
string0 = "gaurav1234@gmail.com"
string1 = "pratik190900234@gmail.com"
string2 = "2009_rocking_person@yahoo.com"
string3 = "GodFather2022@yahoo.com"
string4 = "Brocklesner_89_WWE@yahoo.com"
string5 = "TheRock_WWE@yahoo.com"
string6 = "JohnCena_WWE@yahoo.com"
string7 = "Undertaker_Roman_reigns@outlook.com"
string8 = "6789764666@rediffmail.com"
string9 = "Kane#6789@gmail.com"

my_list = [string0,string1,string2,string3,string4,string5,string6,string7,string8,string9]

#1)emails that do have special characters of #~`!
(print("---Emails with special characters #~`!---\n"))
pattern = "[#~`!]"
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)
print("__________________________________________________________________________________")


#2)emails that start with numbers
print("--- Emails start with numbers --\n")
pattern = "[0-9]"
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)

print("__________________________________________________________________________________________")


#3)emails that start with number followed by an underscore
print("--- Emails start with numbers and underscores --\n")       
pattern = "[0-9]_ "
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)

print("________________________________________________________________________________________")


print("--- Emails start with numbers,underscores and lowercase ---\n")       
#4)emails that start with number followed by an underscore or small case underscore
pattern = "[_abc]+"
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)
print("--- Emails start with numbers,underscores and lowercase/uppercase ---\n")



#5)emails that start with number followed by an underscore or small charachter or large charachter
pattern = "[_a-zA-Z]+"
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)

print("____________________________________________________________________________________________")

print("--- Emails start with only numbers before the @ ---\n")
#6)emails with only numbers before the @
pattern = "^\d+@"
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)

print("_________________________________________________________________________________________")

print("--- Emails with numbers anywhere before th @ ---\n")
#7)emails with numbers anywhere before the @
pattern = "\d+@"
for emails in my_list:
    if re.search(pattern,emails):
        print(emails)
