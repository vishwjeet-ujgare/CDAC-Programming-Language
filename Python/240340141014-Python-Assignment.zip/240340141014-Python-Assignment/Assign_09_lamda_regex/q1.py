# 1)  Convert following functions from function_definitions.py into lambda 
#     and call them 
    
def main():
    num1 = int(input('Enter first number: '))
    num2 = int(input('Enter second number: '))
    
    
    my_lambda_add_func = lambda num1, num2 : num1+num2
    print("addition of two number is  : ",my_lambda_add_func(num1 , num2))
    
    my_lambda_sub_func = lambda num1 , num2: num1-num2 
    print("substaction of numbers is : " , my_lambda_sub_func(num1 , num2))
    
    
    my_lambda_multi_func = lambda num1 ,num2: num1*num2
    print("multiplication of  number is : " , my_lambda_multi_func(num1 , num2))
    
    
    my_lambda_div_func = lambda num1 ,num2: num1/num2
    print("division of  number is : " , my_lambda_div_func(num1))
    
    
    my_lambda_square_func = lambda num1: num1*num1
    print("square of first number is : " , my_lambda_square_func(num1))
    
    my_lambda_square_func = lambda num2: num2*num2
    print("square of second number is : " , my_lambda_square_func(num2))
    
    # my_lambda_square_func = lambda num1: num1 pow num2
    # print("square of first number is : " , my_lambda_square_func(num1))
    
    
    
    
    
    
    
    
main()    
    
    


 