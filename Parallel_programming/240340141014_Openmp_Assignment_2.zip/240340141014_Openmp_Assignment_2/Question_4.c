#include <stdio.h>
#include <omp.h>

#define ARRAY_SIZE 100

int main() {
    int array[ARRAY_SIZE];
    int result_and = 0xFFFFFFFF;
    int result_or = 0x00000000;
    int result_xor = 0x00000000;

    // Initialize array
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        array[i] = i + 1;
    }

    #pragma omp parallel for reduction(&&:result_and) reduction(||:result_or) reduction(^:result_xor)
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        result_and &= array[i];
        result_or |= array[i];
        result_xor ^= array[i];
    }

    printf("Bitwise AND result: %X\n", result_and);
    printf("Bitwise OR result: %X\n", result_or);
    printf("Bitwise XOR result: %X\n", result_xor);

    return 0;
}
