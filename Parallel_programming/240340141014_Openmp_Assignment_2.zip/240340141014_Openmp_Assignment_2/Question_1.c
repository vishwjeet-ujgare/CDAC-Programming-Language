#include <stdio.h>
#include <omp.h>

#define NUM 10000

int isprime(int num) {
    if (num <= 1) return 0;
    if (num <= 3) return 1;
    if (num % 2 == 0 || num % 3 == 0) return 0;
    for (int i = 5; i * i <= num; i += 6) {
        if (num % i == 0 || num % (i + 2) == 0) return 0;
    }
    return 1;
}

int main() {
    int count = 0;

    #pragma omp parallel for reduction(+:count)
    for (int i = 2; i <= NUM; ++i) {
        if (isprime(i)) {
            count++;
        }
    }

    printf("Total number of prime numbers up to %d: %d\n", NUM, count);

    return 0;
}
