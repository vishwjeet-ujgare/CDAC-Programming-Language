#include <stdio.h>
#include <omp.h>

#define ARRAY_SIZE 100

int main() {
    int sum = 0;
    int array[ARRAY_SIZE];
    long long product = 1;
    long long product_local;

 
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        array[i] = i + 1;
    }

    #pragma omp parallel for reduction(+:sum)
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        sum += array[i];
    }

    
    #pragma omp parallel
    {
        product_local = 1;
        #pragma omp for
        for (int i = 0; i < ARRAY_SIZE; ++i) {
            product_local *= array[i];
        }
        #pragma omp critical
        {
            product *= product_local;
        }
    }

    printf("Sum of array elements: %d\n", sum);
    printf("Product of array elements: %lld\n", product);

    return 0;
}
