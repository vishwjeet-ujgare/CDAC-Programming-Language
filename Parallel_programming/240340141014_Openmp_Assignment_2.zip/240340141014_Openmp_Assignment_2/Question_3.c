#include <stdio.h>
#include <limits.h>
#include <omp.h>

#define ARRAY_SIZE 100

int main() {
    int array[ARRAY_SIZE];
    int min = INT_MAX;
    int max = INT_MIN;

    for (int i = 0; i < ARRAY_SIZE; ++i) {
        array[i] = i + 1;
    }

    #pragma omp parallel for reduction(min:min) reduction(max:max)
    for (int i = 0; i < ARRAY_SIZE; ++i) {
        if (array[i] < min) {
            min = array[i];
        }
        if (array[i] > max) {
            max = array[i];
        }
    }

    printf("Minimum value in the array: %d\n", min);
    printf("Maximum value in the array: %d\n", max);

    return 0;
}
